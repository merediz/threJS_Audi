var container, stats;

var camera, scene, renderer;

var sphereBig, plane, cylinder, sphere, group;

var targetRotationX = 0;
var targetRotationY = 0;
var targetRotationOnMouseDownX = 0;
var targetRotationOnMouseDownY = 0;

var mouseX = 0;
var mouseY = 0;
var mouseXOnMouseDown = 0;

var windowHalfX = window.innerWidth / 2;
var windowHalfY = window.innerHeight / 2;

init();
animate();

function init() {

	container = document.createElement( 'div' );
	document.body.appendChild( container );

	var info = document.createElement( 'div' );
	info.style.position = 'absolute';
	info.style.top = '10px';
	info.style.width = '100%';
	info.style.textAlign = 'center';
	container.appendChild( info );

	camera = new THREE.PerspectiveCamera( 70, window.innerWidth / window.innerHeight, 1, 1000 );
	camera.position.y = 0;
	camera.position.z = 600;

	scene = new THREE.Scene();

	//Esfera grande

	var geometry = new THREE.SphereGeometry( 80, 26, 36);

	var material = new THREE.MeshLambertMaterial( { color: 0xcc66ff} );

	sphereBig = new THREE.Mesh( geometry, material );
	sphereBig.position.y = 120;
	sphereBig.position.z = 320;
	
	// Esfera chica

	var geometry = new THREE.CylinderGeometry( 5, 5, 50, 50 );
	var material = new THREE.MeshLambertMaterial( {color: 0x9999ff} );
	cylinder = new THREE.Mesh( geometry, material );

	//Esfera

	var geometry = new THREE.SphereGeometry( 50, 26, 36);

	var material = new THREE.MeshLambertMaterial( { color: 0xff6600 } );

	sphere = new THREE.Mesh( geometry, material );
	sphere.position.y = -75;

		/* -------------------------------------- */

	group = new THREE.Object3D();
	group.add( sphereBig );
	//group.add( plane );
	group.add( sphere );
	group.add( cylinder );
	scene.add( group );

		/* -------------------------------------- */

	var pointLight = new THREE.PointLight(0xff6600);
	pointLight.position.x = 120;
	pointLight.position.y = 120;
	pointLight.position.z = 121;
	scene.add( pointLight );

	var pointLight = new THREE.PointLight(0x0000FF);
	pointLight.position.x = -120;
	pointLight.position.y = -120;
	pointLight.position.z = 121;
	scene.add( pointLight );

	renderer = new THREE.WebGLRenderer();
	renderer.setClearColor( 0x000000 );
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
	container.appendChild( renderer.domElement );


	stats = new Stats();
	stats.domElement.style.position = 'absolute';
	stats.domElement.style.top = '0px';
	container.appendChild( stats.domElement );





	document.addEventListener( 'mousedown', onDocumentMouseDown, false );
	document.addEventListener( 'touchstart', onDocumentTouchStart, false );
	document.addEventListener( 'touchmove', onDocumentTouchMove, false );

	//

	window.addEventListener( 'resize', onWindowResize, false );

}

function onWindowResize() {

	windowHalfX = window.innerWidth / 2;
	windowHalfY = window.innerHeight / 2;

	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();

	renderer.setSize( window.innerWidth, window.innerHeight );

}

//

function onDocumentMouseDown( event ) {

	event.preventDefault();

	document.addEventListener( 'mousemove', onDocumentMouseMove, false );
	document.addEventListener( 'mouseup', onDocumentMouseUp, false );
	document.addEventListener( 'mouseout', onDocumentMouseOut, false );

	mouseXOnMouseDown = event.clientX - windowHalfX;
	mouseYOnMouseDown = event.clientY - windowHalfY;
	targetRotationOnMouseDownX = targetRotationX;
	targetRotationOnMouseDownY = targetRotationY;

}

function onDocumentMouseMove( event ) {

	mouseX = event.clientX - windowHalfX;
	mouseY = event.clientY - windowHalfY;

	targetRotationX = targetRotationOnMouseDownX + ( mouseX - mouseXOnMouseDown ) * 0.02;
	targetRotationY = targetRotationOnMouseDownY + ( mouseY - mouseYOnMouseDown ) * 0.02;

}

function onDocumentMouseUp( event ) {

	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );

}

function onDocumentMouseOut( event ) {

	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );

}

function onDocumentTouchStart( event ) {

	if ( event.touches.length === 1 ) {

		event.preventDefault();

		mouseXOnMouseDown = event.touches[ 0 ].pageX - windowHalfX;
		mouseYOnMouseDown = event.touches[ 0 ].pageY - windowHalfY;
		targetRotationOnMouseDownX = targetRotationX;
		targetRotationOnMouseDownY = targetRotationY;

	}

}

function onDocumentTouchMove( event ) {

	if ( event.touches.length === 1 ) {

		event.preventDefault();

		mouseX = event.touches[ 0 ].pageX - windowHalfX;
		targetRotationX = targetRotationOnMouseDownX + ( mouseX - mouseXOnMouseDown ) * 0.05;

		mouseY = event.touches[ 0 ].pageX - windowHalfY;
		targetRotationY = targetRotationOnMouseDownY + ( mouseY - mouseYOnMouseDown ) * 0.05;

	}

}

//

function animate() {

	requestAnimationFrame( animate );

	render();
	stats.update();

}

function render() {

	group.rotation.y += ( targetRotationX - group.rotation.y ) * 0.05;
	group.rotation.x += ( targetRotationY - group.rotation.x ) * 0.05;
	renderer.render( scene, camera );

}
